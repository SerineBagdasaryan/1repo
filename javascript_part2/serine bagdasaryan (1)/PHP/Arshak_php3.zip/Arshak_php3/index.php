<?php
for ($row1 = 0; $row1 < 12; $row1++) {
    for ($column1 = 0; $column1 < 11; $column1++) {

        if (($row1 == 5) && ($column1 >= 0 || $column1 <= 10)||
            (($column1 > 0 && $column1 < 10) && ($row1 == 0)) ||
            ($column1 == 0 || $column1 == 10) && ($row1 != 0 && $row1 != 5)
        ) {
            echo "*";
        } else {
            echo "&nbsp;&nbsp;";
        }
    }
    echo "<br>";
}
?>