<?php

if (isset($_POST['username']) && $_POST['username']
    && isset($_POST['name']) && $_POST['name']
    && isset($_POST['lastname']) && $_POST['lastname']
    && isset($_POST['email']) && $_POST['email']
    && isset($_POST['pass']) && $_POST['pass']
    && isset($_POST['c_pass']) && $_POST['c_pass']
) {
    if (Username($_POST['username'])) {
        echo "Username is: " . trim($_POST['username']);
    } else {
        echo 'Username contains non letter characters';
    }
    echo "<br>";
    if (Name($_POST['name'])) {
        echo "Name is: " . $_POST['name'];
    } else {
        echo "Name contains non letter characters";
    }
    echo "<br>";
    if (Name($_POST['lastname'])) {
        echo "Lastname is: " . $_POST['lastname'];
    } else {
        echo "Lastname contains non letter characters";
    }
    echo "<br>";
    echo "Email is: " . $_POST['email'];
    echo "<br>";

    if (pass($_POST['pass'])) {
        echo "Password is: " . sha1($_POST['pass']);
    } else {
        echo "Password contains non letter characters";
    }
    echo "<br>";
    echo "Confirm password is: " . sha1(C_pass($_POST['c_pass']));
} else {
    echo "data is not full";
}
echo "<br>";
//CHECKBOX


$yes = $_POST['door'];
if (empty($yes)){
    echo "выбирайте хоть одну зданию";
}else{
    $n = count($yes);

    echo "Вы выбрали $n здание(й): ";
    for ($i = 0; $i < $n; $i++){
        echo $yes[$i] . " ";
    }
}
echo "<br>";




//DATE

$data = date(Y);
$bDay = $_POST['b_day'];
if ($data - $bDay < 16){
    echo "you are children yet. GOODBYE";
}else{
    echo "WELCOME";
}





function Username($str)
{
    $patt = '/^[\S]{0,}$/i';
    if (preg_match($patt, $str, $matces)) {
        return true;
    } else {
        return false;
    }
}

function Name($str)
{
    $patt = '/^[a-zA-Z]+$/i';
    if (preg_match($patt, $str, $matces)) {
        return true;
    } else {
        return false;
    }
}

function Pass($str)
{
    $patt = '/^[A-Za-z].*[0-9]|[0-9].*[A-Za-z]$/i';
    if (preg_match($patt, $str, $matces)) {
        return true;
    } else {
        return false;
    }
}

function C_pass($str)
{
    if ($_POST['pass'] == $str) {
        return $str;
    } else {
        return "error";
    }
}

