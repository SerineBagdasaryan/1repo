<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="http://style.css.loc/style.css">
    <style>

        form{
            text-align: center;
        }
        form input{
            margin: 15px 10px;
        }
    </style>
</head>
<body>
<div class="container">
    <form method="post" action="http://work5.loc/index.php">
        Username* <input type="text" name="username"><br>
        Name* <input type="text" name="name"><br>
        Last name* <input type="text" name="lastname"><br>
        Email Address* <input type="email" name="email"><br>
        Password* <input type="password" name="pass"><br>
        Confirm your password* <input type="password" name="c_pass"><br>
        Subscription: <input type="checkbox" name="door[]" value="A"> Tips and discounts<br>
        <input type="checkbox" name="door[]" value="B"> Newsletters<br>
        <input type="date" name="b_day"><br>
        <input type="submit" value="register">
        <input type="reset" name="cancel" value="Cancel">
    </form>
</div>

</body>
</html>


<?php
