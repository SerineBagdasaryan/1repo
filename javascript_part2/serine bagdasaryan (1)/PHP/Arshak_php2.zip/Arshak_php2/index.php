<?php

function small($a, $b)
{
    if ($a > $b) {
        $c = $a;
    } else {
        $c = $b;
    }
    return $c;
}

echo small(15, 26);
echo "<br>";

function big($a, $b)
{
    if ($a > $b) {
        $c = $b;
    } else {
        $c = $a;
    }
    return $c;
}

echo big(34, 42);
echo "<br>";

function bet($a, $b)
{
    $c = ($a + $b) / 2;
    return $c;
}

echo bet(15, 23);
echo "<br>";
function arr($q, $f)
{
    $d = $q + $f;
    return $d;
}

print_r(arr([0 => "12", "color" => "blue", 1 => "Sako"], [2 => "John", "bg_color" => "brown", 3 => 24, 4 => 75]));
echo "<br>";
date_default_timezone_set('Asia/Yerevan');
echo date(Y . "-" . M . "-" . d . " " . H . ":" . i . ":" . s);
echo "<br>";
echo date(Y . "-" . M . "-" . d . " " . h . ":" . i . ":" . s);
echo "<br>";
echo date(l . " " . d . " " . F . " " . Y . " " . h . ":" . i . ":" . s . " " . A);
echo "<br>";
$a = time();
echo date(D . " " . d . " " . M . " " . Y . " " . h . ":" . i . ":" . s, 1509183000);

echo "<br>";

$products = array();
$products[] = array("name" => "Ծիրան", "in_stock" => true);
$products[] = array("name" => "Խաղող", "in_stock" => false);
$products[] = array("name" => "Ձմերուկ", "in_stock" => false);
$products[] = array("name" => "Նուռ", "in_stock" => true);
$products[] = array("name" => "Ելակ", "in_stock" => false);
for($d = 0; $d < count($products);$d++){
    foreach ($products[$d] as $a => $b) {
        $c = array_search(true, $products[$d], true);
        if ($c){
            print_r("$b");
            echo "<br>";
        }
    }
}



