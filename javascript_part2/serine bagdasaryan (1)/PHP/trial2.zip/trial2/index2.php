<?php
    $array = [['a login', 'a password'], ['b login', 'b password']];

    if($_POST['login']){
        foreach($array as $key => $value){
            if($_POST['login'] == $value[0]){
                echo 'Ok';
                break;
            }else{
                echo 'error <br>';
            }
        }
    }else{
        echo 'There is not';
    }
?>
