
<form method='post' action='index2.php'>
    <input type="text" name="login" placeholder='login'><br>
    <input type="text" name="password" placeholder="password"><br>
    <input type="submit" name="" value="Submit">
</form>
