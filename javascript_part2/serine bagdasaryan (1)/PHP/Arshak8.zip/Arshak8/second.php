<?php include 'index.php';


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mysite";
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    //                     CREATE DATABASE
//    $sql = "Create Database mysite";

    //                     CREATE TABLE
//    $sql = "Create Table if not EXISTS users(
//id INT AUTO_INCREMENT,
//username VARCHAR (50) NOT NULL UNIQUE ,
//firstname VARCHAR (50) NOT  NULL,
//lastname VARCHAR (60) NOT NULL,
//email VARCHAR (60) NOT NULL UNIQUE ,
//password VARCHAR (60) NOT NULL,
//r_password VARCHAR (60) NOT NULL,
//PRIMARY KEY (id)
//)charset=utf8 ENGINE=INNODB";

//       INSERT INTO

    $ins = $conn->prepare("Insert Into users(username, firstname, lastname, email, password, r_password)
              VALUES (:username, :firstname, :lastname, :email, :password, :r_password)");

    $ins->bindParam(':username',$a);
    $ins->bindParam(':firstname',$b);
    $ins->bindParam(':lastname',$c);
    $ins->bindParam(':email',$d);
    $ins->bindParam(':password',$f);
    $ins->bindParam(':r_password',$g);

    $a = $arr[0];
    $b = $arr[1];
    $c = $arr[2];
    $d = $arr[3];
    $f = $arr[4];
    $g = $arr[5];
    $ins->execute();

//    $conn->exec($sql);
    echo "New user created successfully<br>";
} catch (PDOException $e) {
    echo $sql . "<br>" . $e->getMessage();
}


$conn = null;
