
<form method="post" action="second.php">
    <input type="text" name="username" placeholder="Username" title="напишите что хотите кроме пробела и перевод строки">
    <input type="text" name="firstname" placeholder="Firstname" title="напишите только ЛАТИНСКИЕ буквы">
    <input type="text" name="lastname" placeholder="Lastname" title="напишите только ЛАТИНСКИЕ буквы">
    <input type="text" name="email" placeholder="Email" title="например_ naprimer@mail.ru">
    <input type="password" name="password" placeholder="Password" title="например_ Asdf1234Asdf">
    <input type="password" name="r_password" placeholder="R_Password" title="например_ Asdf1234Asdf">
    <input type="submit">
</form>
<?php


if ($_SERVER["REQUEST_METHOD"]=="POST"){
    if (isset($_POST['username']) && isset($_POST['firstname']) &&
        isset($_POST['lastname']) && isset($_POST['email']) &&
            isset($_POST['password']) && isset($_POST['r_password'])
        ){


        if (login($_POST['username'])){
            $u_name = trim($_POST['username']);
        }else{
            echo 'Username contains non letter characters';
        }

        if (Name($_POST['firstname'])){
            $name = $_POST['firstname'];
        }else{
            echo "Firstname contains non letter characters";
        }
        if (Name($_POST['lastname'])){
            $surname = $_POST['lastname'];
        }else{
            echo "Lastname contains non letter characters";
        }

        if (email($_POST['email'])){
            $email = $_POST['email'];
        }else{
            echo "Email contains non letter characters";
        }

        if (Pass($_POST['password'])){
            $pass = sha1($_POST['password']);
        }else {
            echo "Password contains non letter characters";
        }
        if (Pass($_POST['r_password'])&& $_POST['password']=$_POST['r_password']){
            $r_pass = sha1($_POST['r_password']);
        }else{
            echo "R_Password contains non letter characters";
        }

        if ($u_name && $name && $surname && $email && $pass && $r_pass){
            $arr = [];
            array_push($arr, $u_name, $name, $surname,$email,$pass, $r_pass);
        }
    }
}

function login($str)
{
    $patt = '/^[\S]{0,}$/i';
    if (preg_match($patt, $str, $matces)) {
        return true;
    } else {
        return false;
    }
}

function Name($str){
    $patt = '/^[A-Za-z]+$/';
    if (preg_match($patt, $str, $matces)){
        return true;
    }else{
        echo "errorrrr";
    }
}

function email($mail){
    $patt = '/^[\w.]+@[a-zA-Z]+.[a-zA-Z]{2,3}$/';
    if (preg_match($patt, $mail, $matces)){
        return  true;
    }else{
        return false;
    }
}

function Pass($str)
{
    $patt = '/^[A-Z][a-z]+[0-9]+[A-Z][a-z]+$/i';
    if (preg_match($patt, $str, $matces)) {
        return true;
    } else {
        return false;
    }
}


?>

