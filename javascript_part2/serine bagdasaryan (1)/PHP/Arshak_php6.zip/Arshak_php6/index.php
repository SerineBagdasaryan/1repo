<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="http:\\arshak-php6.loc\style.css">
</head>
<body>
<div>

</div>
    <ul>
        <li><a href="second/index.php?1">Post-1</a></li>
        <li><a href="second/index.php?2">Post-2</a></li>
        <li><a href="second/index.php?3">Post-3</a></li>
        <li><a href="second/index.php?4">Post-4</a></li>
        <li><a href="second/index.php?5">Post-5</a></li>
    </ul>
</body>
</html>




