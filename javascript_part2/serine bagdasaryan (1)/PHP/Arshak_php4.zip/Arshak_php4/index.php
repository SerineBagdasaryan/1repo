<?php
/*        FAKTORIAL
function fakt($num){

    $asd = 1;
    for ($a = $num; $a >= 1; $a--) {
        $asd = $asd * $a;
    }
    return $asd;
}

echo fakt(5);

*/


/*               AXUSYAK
echo "<table style='border: 1px solid'>";
for($x = 1; $x <= 10; $x++){
    echo "<tr>";
    for ($y = 1; $y <= 10; $y++){
        echo "<td style='border: 1px solid'>";
        echo $y*$x;
        echo "</td>";
    }
    echo "</tr>";
}
echo "</table>";
*/


/*              ZET
for ($w = 0; $w < 7; $w++) {
    for ($z = 0; $z < 7; $z++) {
        if (($w != 0 && $w != 6) &&($w +$z < 6 || $w + $z > 6)){
            echo "&nbsp;&nbsp;";
        }else{
            echo "*";
        }

    }
    echo "<br>";
}


     // SEXAN
for ($a = -5; $a <= 5; $a++) {
        if ($a != 0){
            for ($b = 6; $b > abs($a);$b--){
                echo "*";
            }
            echo "<br>";
        }
}
*/


//          parz tiv
//function parz($x){
//    if ($x == 1){
//        return "1";
//    }else{
//        for ($y = 2; $y * $y <= $x; $y++){
//            if ($x % $y == 0){
//                return "parz che";
//            }
//        }
//        return "parz e";
//    }
//}
//echo parz(40);


