
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<form method="post" action="index.php">
    <input type="text" name="r_name">
    <input type="password" name="r_pass">
    <input type="submit" value="register">
</form>
<form method="post" action="index2.php">
    <input type="text" name="username">
    <input type="password" name="password">
    <input type="submit" name="log_in" value="entrance">
</form>
</body>
</html>

<?php


$myfirst = fopen('file.txt', 'a+')or die("errorrr");
if ($_SERVER["REQUEST_METHOD"]=="POST"){
    if (isset($_POST['r_name']) && isset($_POST['r_pass'])){


        if (login($_POST['r_name'])){
            $rname = trim($_POST['r_name']);
        }else{
            echo 'Username contains non letter characters';
        }

        if (Pass($_POST['r_pass'])){
            $rpass = sha1($_POST['r_pass']);
        }else {
            echo "Password contains non letter characters";
        }

        if ($rname && $rpass){
            $text = $rname.",,".$rpass.",,,";
            fwrite($myfirst, $text);
        }
    }
}

function login($str)
{
    $patt = '/^[\S]{0,}$/i';
    if (preg_match($patt, $str, $matces)) {
        return true;
    } else {
        return false;
    }
}

function Pass($str)
{
    $patt = '/^[A-Za-z].*[0-9]|[0-9].*[A-Za-z]$/i';
    if (preg_match($patt, $str, $matces)) {
        return true;
    } else {
        return false;
    }
}

?>


