<?php include "index.php";
$myfile = fopen('file.txt', 'a+') or die("errorrr");

$array = [];
while (!feof($myfile)) {
    $arr = explode(",,,", fgets($myfile));
    foreach ($arr as $i => $k) {
        $arr[$i] = explode(',,', $k);
    }
    array_push($array, $arr);
}
//echo '<pre>';
//print_r($array);die;

if (!empty($_POST['username']) || !empty($_POST['password'])) {
    $username = $_POST['username'];
    $appropr_username = '';
    for ($a = 0; $a < count($array); $a++) {
        foreach ($array[$a] as $key => $value) {
            if ($username == $value[0]) {
                $appropr_username = "Հաջողությամբ մուտք եք գործել";
            }
        }
    }
}else {
    echo "errorrrr";
}

if ($appropr_username) {
    echo $appropr_username;
} else {
    echo "մուտքագրված տվյալները սխալ են";
}


?>