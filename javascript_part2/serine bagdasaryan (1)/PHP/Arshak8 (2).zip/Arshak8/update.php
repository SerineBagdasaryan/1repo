<form method="post" action="update.php">
    <input type="text" name="username" placeholder="Username"
           title="напишите что хотите кроме пробела и перевод строки">
    <input type="text" name="firstname" placeholder="Firstname" title="напишите только ЛАТИНСКИЕ буквы">
    <input type="text" name="lastname" placeholder="Lastname" title="напишите только ЛАТИНСКИЕ буквы">
    <input type="email" name="email" placeholder="Email" title="например_ naprimer@mail.ru">
    <input type="password" name="password" placeholder="Password" title="например_ Asdf1234Asdf">
    <input type="password" name="r_password" placeholder="R_Password" title="например_ Asdf1234Asdf">
    <input type="submit" value="UPDATE">
    <input type="number" name="ID" placeholder="ID">
</form>


<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (login($_POST['username'])) {
        $u_name = trim($_POST['username']);
    }

    if (Name($_POST['firstname'])) {
        $name = $_POST['firstname'];
    }

    if (Name($_POST['lastname'])) {
        $surname = $_POST['lastname'];
    }


    if (email($_POST['email'])) {
        $email = $_POST['email'];
    }

    if (isset($_POST['password']) && isset($_POST['r_password'])) {
        if (Pass($_POST['password'])) {
            $pass = sha1($_POST['password']);
        }

        if (Pass($_POST['r_password']) && $_POST['password'] = $_POST['r_password']) {
            $r_pass = sha1($_POST['r_password']);
        }

        $ID = $_POST['ID'];
    } else {
        echo "Երկուսն էլ Մուտքագրեք";
    }


    if ($u_name && $name && $surname && $email && $pass && $r_pass) {
        $array = [];
        array_push($array, $u_name, $name, $surname, $email, $pass, $r_pass);
    }

}

function login($str)
{
    $patt = '/^[\S]{0,}$/i';
    if (preg_match($patt, $str, $matces)) {
        return true;
    } else {
        return false;
    }
}

function Name($str)
{
    $patt = '/^[A-Za-z]+$/';
    if (preg_match($patt, $str, $matces)) {
        return true;
    } else {
        echo false;
    }
}

function email($mail)
{
    $patt = '/^[\w.]+@[a-zA-Z]+.[a-zA-Z]{2,3}$/';
    if (preg_match($patt, $mail, $matces)) {
        return true;
    } else {
        return false;
    }
}

function Pass($str)
{
    $patt = '/^[A-Z][a-z]+[0-9]+[A-Z][a-z]+$/i';
    if (preg_match($patt, $str, $matces)) {
        return true;
    } else {
        return false;
    }
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mysite";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

//    foreach ($array as $value){
//        $res = $value;
//    }

    $sql = "Update users SET username='$u_name', firstname='$name', 
                    lastname='$surname', email='$email', password='$pass', 
                     r_password='$r_pass'WHERE id =".$ID;

    $stmt = $conn->prepare($sql);

    $stmt->execute();
    echo "user updated successfully";
} catch (PDOException $e) {
    echo $sql . "<br>" . $e->getMessage();
}
