
<form method="post" action="index.php">
    <input type="text" name="username" placeholder="Username" title="напишите что хотите кроме пробела и перевод строки">
    <input type="text" name="firstname" placeholder="Firstname" title="напишите только ЛАТИНСКИЕ буквы">
    <input type="text" name="lastname" placeholder="Lastname" title="напишите только ЛАТИНСКИЕ буквы">
    <input type="text" name="email" placeholder="Email" title="например_ naprimer@mail.ru">
    <input type="password" name="password" placeholder="Password" title="например_ Asdf1234Asdf">
    <input type="password" name="r_password" placeholder="R_Password" title="например_ Asdf1234Asdf">
    <input type="submit">
</form>
<a href="delete.php" target="_blank">DELETE PROFILE</a>
<a href="update.php" target="_blank">UPDATE PROFILE INFO</a>
<?php


if ($_SERVER["REQUEST_METHOD"]=="POST"){
    if (isset($_POST['username']) && isset($_POST['firstname']) &&
        isset($_POST['lastname']) && isset($_POST['email']) &&
            isset($_POST['password']) && isset($_POST['r_password'])
        ){


        if (login($_POST['username'])){
            $u_name = trim($_POST['username']);
        }else{
            echo 'Username contains non letter characters';
        }

        if (Name($_POST['firstname'])){
            $name = $_POST['firstname'];
        }else{
            echo "Firstname contains non letter characters";
        }
        if (Name($_POST['lastname'])){
            $surname = $_POST['lastname'];
        }else{
            echo "Lastname contains non letter characters";
        }

        if (email($_POST['email'])){
            $email = $_POST['email'];
        }else{
            echo "Email contains non letter characters";
        }

        if (Pass($_POST['password'])){
            $pass = sha1($_POST['password']);
        }else {
            echo "Password contains non letter characters";
        }
        if (Pass($_POST['r_password'])&& $_POST['password']=$_POST['r_password']){
            $r_pass = sha1($_POST['r_password']);
        }else{
            echo "R_Password contains non letter characters";
        }

        if ($u_name && $name && $surname && $email && $pass && $r_pass){
            $arr = [];
            array_push($arr, $u_name, $name, $surname,$email,$pass, $r_pass);
        }
    }else{
        echo "մուտքագրեք ամբողջ տվյալները<br>";
    }
}

function login($str)
{
    $patt = '/^[\S]{0,}$/i';
    if (preg_match($patt, $str, $matces)) {
        return true;
    } else {
        return false;
    }
}

function Name($str){
    $patt = '/^[A-Za-z]+$/';
    if (preg_match($patt, $str, $matces)){
        return true;
    }else{
        echo "errorrrr";
    }
}

function email($mail){
    $patt = '/^[\w.]+@[a-zA-Z]+.[a-zA-Z]{2,3}$/';
    if (preg_match($patt, $mail, $matces)){
        return  true;
    }else{
        return false;
    }
}

function Pass($str)
{
    $patt = '/^[A-Z][a-z]+[0-9]+[A-Z][a-z]+$/i';
    if (preg_match($patt, $str, $matces)) {
        return true;
    } else {
        return false;
    }
}
//                                  MYSQL CONNECTION
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mysite";
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    //                     CREATE DATABASE
//    $sql = "Create Database mysite";

    //                     CREATE TABLE
//    $sql = "Create Table if not EXISTS users(
//id INT AUTO_INCREMENT,
//username VARCHAR (50) NOT NULL UNIQUE ,
//firstname VARCHAR (50) NOT  NULL,
//lastname VARCHAR (60) NOT NULL,
//email VARCHAR (60) NOT NULL UNIQUE ,
//password VARCHAR (60) NOT NULL,
//r_password VARCHAR (60) NOT NULL,
//PRIMARY KEY (id)
//)charset=utf8 ENGINE=INNODB";
//    $conn->exec($sql);
//       INSERT INTO

    $insert = $conn->prepare("Insert Into users(username, firstname, lastname, email, password, r_password)
              VALUES (:username, :firstname, :lastname, :email, :password, :r_password)");

    $insert->bindParam(':username', $a);
    $insert->bindParam(':firstname', $b);
    $insert->bindParam(':lastname', $c);
    $insert->bindParam(':email', $d);
    $insert->bindParam(':password', $f);
    $insert->bindParam(':r_password', $g);

    $a = $arr[0];
    $b = $arr[1];
    $c = $arr[2];
    $d = $arr[3];
    $f = $arr[4];
    $g = $arr[5];
    $insert->execute();

    echo "user inserted successfully<br>";


} catch (PDOException $e) {
    echo $sql . "<br>" . $e->getMessage()."<br>";
}
$conn = null;


//                          SHOW BY TABLES
echo "<table style='border: solid 1px black;'>";
echo "<tr><th>Id</th><th>Username</th><th>Firstname</th><th>Lastname</th><th>Email</th></tr>";


class Table extends RecursiveIteratorIterator
{
    function construct($iterator)
    {
        parent::__construct($iterator, self::LEAVES_ONLY);
    }

    function current()
    {
        return "<td style='border: 1px solid'>" . parent::current() . "</td>";
    }

    function beginChildren()
    {
        echo "<tr>";
    }

    function endChildren()
    {
        echo "</tr>";
    }
}

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    //                 select users table
    $ins = $conn->prepare('Select id, username, firstname, lastname, email From users');
    $ins->execute();

    $rezult = $ins->setFetchMode(PDO::FETCH_ASSOC);

    foreach (new Table(new RecursiveArrayIterator($ins->fetchAll())) as $key => $value) {
        echo $value;
    }

    echo "</table>";

} catch (PDOException $e) {
    echo $ins . "<br>" . $e->getMessage();
}
$conn = null;


?>

