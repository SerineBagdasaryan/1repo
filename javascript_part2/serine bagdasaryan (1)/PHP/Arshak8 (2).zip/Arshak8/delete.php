<form method="post" action="delete.php">
    <input type="text" name="Email">
    <input type="submit" value="DELETE">
</form>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mysite";

try{
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //   DELETE
    $Email = $_POST['Email'];
    $del = "DELETE FROM users WHERE email='$Email'";

    $conn->exec($del);

    echo "user deleted successfully<br>";
} catch (PDOException $e) {
    echo $del . "<br>" . $e->getMessage();
}
$conn = null;